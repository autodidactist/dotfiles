local g = vim.g
local o = vim.o
local A = vim.api
