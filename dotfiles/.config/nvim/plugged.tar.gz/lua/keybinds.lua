-- m - mode
-- k - key
-- v - value
-- n - normal mode
-- i - insert mode
-- x - visual mode

local function map(m, k, v) 
   vim.keymap.set(m, k, v, { silent = true })
end

map('n', 'n', 'nzz')
map('n', 'N', 'Nzz')

map('n', '<leader>]', ':bn<CR>')
map('n', '<leader>[', ':bp<CR>')

map('n', '<C-\\>', ':vsplit<CR>')
map('n', '<A-\\>', ':split<CR>')

map('n', '""', ':b#<CR>')

map('n', '<C-j>', ':move .+1<CR>')
map('n', '<C-k>', ':move .-2<CR>')
map('x', '<C-j>', ":move '>+1<CR>gv=gv")
map('x', '<C-j>', ":move '<-2<CR>gv=gv")
