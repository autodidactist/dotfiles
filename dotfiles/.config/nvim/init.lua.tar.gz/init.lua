require('settings')
require('autocmd')
require('keybinds')
require('plugins')

